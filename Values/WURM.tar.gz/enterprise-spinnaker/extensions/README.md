# OpsMx Enterprise Spinnaker Extensions

Extensions provides stages that enhances the functionality of 
Open Source Spinnaker. 

For more information, visit https://www.opsmx.com
