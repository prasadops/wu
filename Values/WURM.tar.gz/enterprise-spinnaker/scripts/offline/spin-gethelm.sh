#!/bin/bash
wget https://kubernetes-charts.storage.googleapis.com/spinnaker-1.23.1.tgz
