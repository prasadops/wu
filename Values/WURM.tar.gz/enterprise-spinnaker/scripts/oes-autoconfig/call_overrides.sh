echo $SPINNAKER_NAMESPACE
sh /tmp/autoconfig/config_overrideurl.sh spin-deck 
sh /tmp/autoconfig/config_overrideurl.sh spin-gate
